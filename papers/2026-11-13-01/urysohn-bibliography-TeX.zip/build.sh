#!/bin/sh
set -eu
cd "$(dirname "$0")"
task_cache_root="${CODEX_LOCAL_STORAGE:-$HOME/localforcodex}/tex/cache/urysohn-bibliography"
mkdir -p build/main build/notes "$task_cache_root/texmf-var" "$task_cache_root/texmf-cache"
TEXMFVAR="$task_cache_root/texmf-var"
TEXMFCACHE="$task_cache_root/texmf-cache"
export TEXMFVAR TEXMFCACHE
latexmk -norc -r .latexmkrc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build/main main.tex
latexmk -norc -r .latexmkrc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build/notes issue-notes.tex
cp build/main/main.pdf main.pdf
cp build/notes/issue-notes.pdf issue-notes.pdf
