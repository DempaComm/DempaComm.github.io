ウリゾーン論文目録（2026-11-13、付録削除版）

main.pdf                  本文9頁：主表39項目、問題欄3件、関連刊行物、
                          根拠・参考文献25件、書誌疑義13件。付録なし。
main.tex                  TeX入口。分割ソースを同じフォルダに置く。
issue-notes.pdf / .tex     書誌疑義・確認ノート（13件、PDF3頁）。
entries.json              編集可能な書誌データと基礎書誌の項目番号対応。
VALIDATION.json           組版・表示・参照の確認記録。
PUBLICATION-MANIFEST.json 公開候補のファイル名・SHA-256・収録範囲。

再コンパイル
XeLaTeX / latexmk / fontspec / xeCJK / Harano Aji / Libertinusを用いる。
このフォルダで ./build.sh を実行すると、補助ファイルはbuild/へ、
完成PDFはこのフォルダへ出力される。main.texとissue-notes.texは
preamble.tex、scope.tex、entries.tex、supplement.tex、issues-body.tex、
references.texを使用する。外部のBibTeX処理は不要。画像入力も不要。

公開配布範囲
本文・注記・参考文献は編集可能なTeXである。公開用ZIPには必要TeX、
編集用データ、新規組版PDF、説明・確認記録だけを収録する。
原本スキャンPDF、原本DjVu、原資料画像、原資料OCR、ローカルの
SOURCE-MANIFEST.json、作業履歴は収録しない。根拠は参考文献と各項目の
確認範囲から追跡できる。原資料はローカルの照合用保管に保持する。

確認の限界
全原誌・全論文の全文校合、個別問題の全署名照合、独立証明監査は未実施。
資料間不一致と未確定事項は本文および別紙へ明記した。
標準総数を確定した完全校合書誌とは主張しない。

表示確認
XeLaTeXで組版し、PDFiumで全頁の表示を確認する。
この環境のPopplerでは和文が空白になるため、そのPNGは確認根拠に使わない。
