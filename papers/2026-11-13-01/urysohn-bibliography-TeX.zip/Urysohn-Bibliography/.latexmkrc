# Unicode Japanese, Cyrillic and European titles use XeLaTeX.
$pdf_mode = 5;
$pdflatex = 'xelatex %O %S';
$xelatex = 'xelatex %O %S';
