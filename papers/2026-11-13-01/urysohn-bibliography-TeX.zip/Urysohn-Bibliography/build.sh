#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/main build/notes build/texmf-var build/texmf-cache
TEXMFVAR="$PWD/build/texmf-var"
TEXMFCACHE="$PWD/build/texmf-cache"
export TEXMFVAR TEXMFCACHE
latexmk -norc -r .latexmkrc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build/main main.tex
latexmk -norc -r .latexmkrc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build/notes issue-notes.tex
cp build/main/main.pdf main.pdf
cp build/notes/issue-notes.pdf issue-notes.pdf
