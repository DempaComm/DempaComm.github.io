ウリゾーン論文目録（2026-11-13 原誌確認改訂版、付録なし）

main.pdf                  本文10頁：主表39項目、個別問題寄稿3件、関連刊行物、
                          参考文献・根拠資料36件、書誌疑義・確認ノート15件。
main.tex                  TeX入口。分割ソースを同じフォルダに置く。
issue-notes.pdf / .tex     書誌疑義・確認ノート（15件、PDF4頁）。本文と同じ内容。
entries.json              編集可能な主表39項目と基礎書誌の項目番号対応。
VALIDATION.json           今回の組版・全頁表示・参照・収録範囲の確認記録。
PUBLICATION-MANIFEST.json 配布用ファイル15点のSHA-256。自身と外側ZIPは対象外。

主な改訂
UR20：65–67頁。UR29：脚注の続きまで含め548–551頁。
UR34：著者順Paul Alexandroff, Paul Urysohn。
UR35：本文296–308頁。308頁下部はHurewiczの別論文への訂正であり、
      ウリゾーンの付属正誤表とした初版の説明を撤回した。
UR36：扉の刊記年1927を採用し、IDを保ったまま年代順の位置を移した。
UR37：原題Ueber Räume mit verschwindender erster Brouwerscher Zahl。
      著者Urysohnと改稿者Alexandroffを区別する。
UR39：著者Urysohnと編集者Stepanoffを区別する。
PR01–PR03：個別問題22（368頁）、29（337頁）、34（279頁）と署名を採用。
RE01・UR38：1950年版は改訂第2版であり、1929年原著の単純再録と扱わない。
AN01：原画像により1915年3月号470–472欄へ確定。題名Henryと署名を確認。
疑義IDは維持し、今回の確定・旧説明の撤回・継続する留保を追跡可能にした。

再コンパイル
XeLaTeX / latexmk / fontspec / xeCJK / Harano Aji / Libertinusを用いる。
このフォルダで ./build.sh を実行する。中間物はbuild/、完成PDFはこの
フォルダへ出力する。再生成可能なTeXキャッシュはホーム配下の
localforcodex/tex/cache/urysohn-bibliographyに置く。CODEX_LOCAL_STORAGEで
ローカル領域を指定できる。外部BibTeX処理や画像入力は不要。

公開配布範囲と確認の限界
本文・注記・参考文献は編集可能なTeXである。ZIPは必要ソース、編集用
データ、PDF、説明・確認記録の16点だけを含む。原本スキャン、DjVu、
原資料画像、OCR、収集台帳、作業履歴は含めない。根拠は各項目と参考
文献から追跡できる。全原論文の全頁校合・版差の全面比較・全著述の
網羅性の証明・独立した数学的証明監査は未実施である。

表示確認
今回XeLaTeXで組版し、PDFiumで本文10頁・別紙4頁すべてを表示確認した。
この環境のPopplerは日本語フォントが欠けるため、代替描画を使用した。
組版・表示確認と、サイト側の公開承認は別の記録で管理する。
